﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ceiling_Function
{
    class Program
    {
        static void Main(string[] args)
        {
            int testcounter = 1;
            int DictionaryCounter = 1;


            string size = Console.ReadLine();

            string[] split = size.Split(' ');

            int numberOfSets = int.Parse(split[0]);
            int numberOfNumbers = int.Parse(split[1]);

            int finalCount = numberOfSets;

            List<int> numberLength = new List<int>();

            for (int i = 1; i <= numberOfSets; i++)
            {
                numberLength.Add(i);
            }

            int[] permutations = numberLength.ToArray();


            Dictionary<int, int[]> tester = new Dictionary<int, int[]>();

            for (int i = 0; i < numberOfSets; i++)
            {
                string userInput = Console.ReadLine();

                string[] splitInput = userInput.Split(' ');

                List<int> IntList = new List<int>();

                for (int j = 0; j < splitInput.Length; j++)
                {
                    IntList.Add(int.Parse(splitInput[j]));
                }
                tester.Add(DictionaryCounter, IntList.ToArray());

                DictionaryCounter++;
            }



            for (int i = 0; i < permutations.Length - 1; i++)
            {
                Tree t = new Tree();

                int k = permutations[i];
                t.StartAdd(tester[k]);

                for (int j = testcounter; j < permutations.Length; j++)
                {
                    Tree t1 = new Tree();

                    int p = permutations[j];

                    if (k != p )
                    {
                        t1.StartAdd(tester[p]);

                        if (t.Compare(t.roots, t1.roots) == true)
                            finalCount--;
                    }
                    p++;
                }
                testcounter++;
            }
            if (finalCount <= 0)
                Console.WriteLine(1);
            else
                Console.WriteLine(finalCount);


            Console.Read();
        }
    }

    public class Node
    {
        public int root;
        public Node left_child;
        public Node right_child;


        public Node(int value)
        {
            root = value;
            left_child = null;
            right_child = null;
        }
        public int rootValue()
        {
            return root;
        }

    }
    public class Tree
    {
        public Node roots;

        public void StartAdd(int[] Number)
        {
            for (int i = 0; i < Number.Length; i++)
            {
                roots = RecursiveAdd(roots, Number[i]);
            }
        }
        private Node RecursiveAdd(Node current, int num)
        {
            if (current == null)
                return new Node(num);
            else if (current.rootValue() > num)
                current.left_child = RecursiveAdd(current.left_child, num);
            else if (current.rootValue() < num)
                current.right_child = RecursiveAdd(current.right_child, num);
            else
                return current;

            return current;
        }
        public bool Compare(Node Comp1, Node Comp2)
        {
            if (Comp1 == null && Comp2 == null)
                return true;

            if (Comp1 == null && Comp2 != null || Comp1 != null && Comp2 == null)
                return false;

            return Compare(Comp1.right_child, Comp2.right_child) && Compare(Comp1.left_child, Comp2.left_child);

        }
    }
}
